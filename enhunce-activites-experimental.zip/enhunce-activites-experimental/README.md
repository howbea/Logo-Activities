# Activities Icon & Label  
How to add your favorite icon  
  
1. Download this extension above and extract it. 

2. Put two icons, which are named start-here and start-here-symbolic at "/my-icon-theme/scalable/places" and put the whole folder at "~/.icons".  
Apply the my-icon-theme icon theme.(edit "Inherit" option in the index.theme if you have a custom one.)  

3. Logout and login again. 
